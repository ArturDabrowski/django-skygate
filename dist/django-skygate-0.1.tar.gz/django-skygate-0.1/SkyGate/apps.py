from django.apps import AppConfig


class SkygateConfig(AppConfig):
    name = 'SkyGate'
