from django.contrib import admin
from .models import ExampleModel

admin.site.register(ExampleModel)
